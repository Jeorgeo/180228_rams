prettyPhoto v3.1.4
© Copyright, Stephane Caron
http://www.no-margin-for-errors.com


============================= Released under =============================

Creative Commons 2.5
http://creativecommons.org/licenses/by/2.5/

OR

GPLV2 license
http://www.gnu.org/licenses/gpl-2.0.html

You are free to use prettyPhoto in commercial projects as long as the
copyright header is left intact.

============================ More information ============================
http://www.no-margin-for-errors.com/projects/prettyPhoto/


============================== Description ===============================

prettyPhoto is a jQuery based lightbox clone. Not only does it support images,
it also add support for videos, flash, YouTube, iFrame. It's a full blown
media modal box.

Please refer to http://www.no-margin-for-errors.com/projects/prettyPhoto/
for all the details on how to use. 
